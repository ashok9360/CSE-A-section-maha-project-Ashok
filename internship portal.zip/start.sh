#!/bin/bash
php -d extension=/home/workspace/my-project/php-mysql-arm64/usr/lib/php/20240924/mysqlnd.so \
-d extension=/home/workspace/my-project/php-mysql-arm64/usr/lib/php/20240924/mysqli.so \
-d extension=/home/workspace/my-project/php-mysql-arm64/usr/lib/php/20240924/pdo_mysql.so \
-S 0.0.0.0:8080 \
-t /home/workspace/my-project/public/internship-portal
