<?php
require_once "config/database.php";

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $password = $_POST["password"];
    $role = $_POST["role"];

    if ($name === "" || $email === "" || $password === "") {
        $error = "Please fill in all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif (strlen($password) < 6) {
        $error = "Password must contain at least 6 characters.";
    } elseif (!in_array($role, ["student", "company"])) {
        $error = "Please select a valid role.";
    } else {
        $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $existing = $check->get_result();

        if ($existing->num_rows > 0) {
            $error = "An account with this email already exists.";
        } else {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $conn->prepare(
                "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)"
            );
            $stmt->bind_param("ssss", $name, $email, $hashedPassword, $role);

            if ($stmt->execute()) {
                $userId = $stmt->insert_id;

                if ($role === "student") {
                    $student = $conn->prepare("INSERT INTO students (user_id) VALUES (?)");
                    $student->bind_param("i", $userId);
                    $student->execute();
                } else {
                    $company = $conn->prepare("INSERT INTO companies (user_id) VALUES (?)");
                    $company->bind_param("i", $userId);
                    $company->execute();
                }

                $success = "Account created successfully. You can now sign in.";
            } else {
                $error = "Unable to create account.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account - Internship Portal</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="auth-page">
<div class="auth-container">
    <div class="auth-brand">
        <a href="index.php" class="logo">Internship<span>Portal</span></a>
        <h1>Start your journey.</h1>
        <p>Create an account and connect students with meaningful internship opportunities.</p>
    </div>

    <div class="auth-card">
        <h2>Create Account</h2>
        <p class="muted">Choose your role and enter your details.</p>

        <?php if ($error): ?>
            <div class="alert error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <form method="POST" onsubmit="return validateRegister()">
            <label>Full Name</label>
            <input type="text" name="name" id="name" placeholder="Enter your name">

            <label>Email Address</label>
            <input type="email" name="email" id="email" placeholder="you@example.com">

         <label>Password</label>
            <input type="password" name="password" id="password" placeholder="Minimum 6 characters">

            <label>Account Type</label>
            <select name="role" id="role">
                <option value="">Select role</option>
                <option value="student">Student</option>
                <option value="company">Company / Admin</option>
         </select>

            <button type="submit" class="btn primary full">Create Account</button>
        </form>

        <p class="auth-bottom">Already have an account? <a href="login.php">Sign in</a></p>
    </div>
</div>
<script src="js/validation.js"></script>
</body>
</html>
