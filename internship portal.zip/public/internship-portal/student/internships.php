<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: ../login.php");
    exit;
}

$search = trim($_GET["search"] ?? "");
$location = trim($_GET["location"] ?? "");

$sql = "SELECT i.*, c.company_name FROM internships i
        JOIN companies c ON i.company_id = c.id
        WHERE i.status = 'Open'";
$params = [];
$types = "";

if ($search !== "") {
    $sql .= " AND (i.title LIKE ? OR i.description LIKE ? OR c.company_name LIKE ?)";
    $term = "%" . $search . "%";
    $params = [$term, $term, $term];
    $types .= "sss";
}

if ($location !== "") {
    $sql .= " AND i.location LIKE ?";
    $params[] = "%" . $location . "%";
    $types .= "s";
}

$sql .= " ORDER BY i.created_at DESC";

$stmt = $conn->prepare($sql);
if ($types !== "") {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Internships - Internship Portal</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "student_nav.php"; ?>
<main class="dashboard">
    <div class="page-heading">
        <div><p class="eyebrow">OPPORTUNITIES</p><h1>Find Internships</h1><p>Search opportunities that match your interests.</p></div>
    </div>

    <form class="search-bar" method="GET">
        <input type="text" name="search" placeholder="Search role, company or keyword" value="<?php echo htmlspecialchars($search); ?>">
        <input type="text" name="location" placeholder="Location" value="<?php echo htmlspecialchars($location); ?>">
        <button class="btn primary" type="submit">Search</button>
    </form>

    <div class="internship-grid">
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="internship-card">
                <span class="status open">Open</span>
                <h2><?php echo htmlspecialchars($row["title"]); ?></h2>
                <h4><?php echo htmlspecialchars($row["company_name"]); ?></h4>
                <p><?php echo htmlspecialchars($row["description"]); ?></p>
                <div class="tags">
                    <span><?php echo htmlspecialchars($row["location"]); ?></span>
                    <span><?php echo htmlspecialchars($row["skills"]); ?></span>
                </div>
                <a class="btn primary" href="apply.php?id=<?php echo $row["id"]; ?>">View & Apply</a>
            </div>
        <?php endwhile; ?>
    </div>
</main>
</body>
</html>
