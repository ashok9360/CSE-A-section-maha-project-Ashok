<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: ../login.php");
    exit;
}

$userId = $_SESSION["user_id"];
$message = "";

$stmt = $conn->prepare("SELECT s.*, u.name, u.email FROM students s JOIN users u ON s.user_id = u.id WHERE s.user_id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $phone = trim($_POST["phone"]);
    $college = trim($_POST["college"]);
    $course = trim($_POST["course"]);
    $skills = trim($_POST["skills"]);
    $bio = trim($_POST["bio"]);
    $resume = $student["resume"];

    if (isset($_FILES["resume"]) && $_FILES["resume"]["error"] === UPLOAD_ERR_OK) {
        $uploadDir = "../uploads/";
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        $extension = strtolower(pathinfo($_FILES["resume"]["name"], PATHINFO_EXTENSION));

        if ($extension === "pdf") {
            $fileName = "resume_" . $userId . "_" . time() . ".pdf";
            if (move_uploaded_file($_FILES["resume"]["tmp_name"], $uploadDir . $fileName)) {
                $resume = $fileName;
            }
        }
    }

    $update = $conn->prepare(
        "UPDATE students SET phone=?, college=?, course=?, skills=?, bio=?, resume=? WHERE user_id=?"
    );
    $update->bind_param("ssssssi", $phone, $college, $course, $skills, $bio, $resume, $userId);

    if ($update->execute()) {
        $message = "Profile updated successfully.";
        $stmt->execute();
        $student = $stmt->get_result()->fetch_assoc();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - Internship Portal</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "student_nav.php"; ?>
<main class="dashboard narrow">
    <div class="page-heading">
        <div><p class="eyebrow">PROFILE</p><h1>My Profile</h1><p>Keep your student information up to date.</p></div>
    </div>

    <?php if ($message): ?><div class="alert success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>

    <div class="form-card">
        <form method="POST" enctype="multipart/form-data">
            <div class="form-grid">
                <div>
                    <label>Name</label>
                    <input type="text" value="<?php echo htmlspecialchars($student["name"]); ?>" disabled>
                </div>
                <div>
                    <label>Email</label>
                    <input type="email" value="<?php echo htmlspecialchars($student["email"]); ?>" disabled>
                </div>
                <div>
                    <label>Phone</label>
                    <input type="text" name="phone" value="<?php echo htmlspecialchars($student["phone"] ?? ""); ?>">
                </div>
                <div>
                    <label>College</label>
                    <input type="text" name="college" value="<?php echo htmlspecialchars($student["college"] ?? ""); ?>">
                </div>
                <div>
                    <label>Course</label>
                    <input type="text" name="course" value="<?php echo htmlspecialchars($student["course"] ?? ""); ?>">
                </div>
                <div>
                    <label>Skills</label>
                    <input type="text" name="skills" placeholder="PHP, MySQL, JavaScript" value="<?php echo htmlspecialchars($student["skills"] ?? ""); ?>">
                </div>
            </div>

            <label>About You</label>
            <textarea name="bio" rows="5" placeholder="Write a short introduction..."><?php echo htmlspecialchars($student["bio"] ?? ""); ?></textarea>

            <label>Resume (PDF)</label>
            <input type="file" name="resume" accept=".pdf">
            <?php if (!empty($student["resume"])): ?><p class="small-text">Current resume uploaded.</p><?php endif; ?>

            <button type="submit" class="btn primary">Save Profile</button>
        </form>
    </div>
</main>
</body>
</html>
