<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: ../login.php");
    exit;
}

$internshipId = intval($_GET["id"] ?? 0);
$userId = $_SESSION["user_id"];
$message = "";

$stmt = $conn->prepare("SELECT i.*, c.company_name FROM internships i JOIN companies c ON i.company_id = c.id WHERE i.id = ?");
$stmt->bind_param("i", $internshipId);
$stmt->execute();
$internship = $stmt->get_result()->fetch_assoc();

$studentStmt = $conn->prepare("SELECT id FROM students WHERE user_id = ?");
$studentStmt->bind_param("i", $userId);
$studentStmt->execute();
$studentId = $studentStmt->get_result()->fetch_assoc()["id"] ?? 0;

if ($_SERVER["REQUEST_METHOD"] === "POST" && $internship) {
    $check = $conn->prepare("SELECT id FROM applications WHERE student_id = ? AND internship_id = ?");
    $check->bind_param("ii", $studentId, $internshipId);
    $check->execute();

    if ($check->get_result()->num_rows > 0) {
        $message = "You have already applied for this internship.";
    } else {
        $apply = $conn->prepare("INSERT INTO applications (student_id, internship_id, status) VALUES (?, ?, 'Applied')");
        $apply->bind_param("ii", $studentId, $internshipId);

        if ($apply->execute()) {
            $message = "Application submitted successfully.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply - Internship Portal</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "student_nav.php"; ?>
<main class="dashboard narrow">
    <?php if (!$internship): ?>
        <div class="alert error">Internship not found.</div>
    <?php else: ?>
        <div class="detail-card">
            <span class="status open">Open</span>
            <h1><?php echo htmlspecialchars($internship["title"]); ?></h1>
            <h3><?php echo htmlspecialchars($internship["company_name"]); ?></h3>
            <p><?php echo nl2br(htmlspecialchars($internship["description"])); ?></p>
            <div class="detail-info">
                <p><strong>Location:</strong> <?php echo htmlspecialchars($internship["location"]); ?></p>
                <p><strong>Skills:</strong> <?php echo htmlspecialchars($internship["skills"]); ?></p>
                <p><strong>Duration:</strong> <?php echo htmlspecialchars($internship["duration"]); ?></p>
                <p><strong>Stipend:</strong> <?php echo htmlspecialchars($internship["stipend"]); ?></p>
            </div>

            <?php if ($message): ?><div class="alert success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>

            <?php if (!$message || strpos($message, "already") !== false): ?>
                <form method="POST">
                    <button class="btn primary" type="submit">Apply Now</button>
                </form>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</main>
</body>
</html>
