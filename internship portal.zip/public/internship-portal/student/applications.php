<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: ../login.php");
    exit;
}

$stmt = $conn->prepare(
    "SELECT a.*, i.title, c.company_name
     FROM applications a
     JOIN students s ON a.student_id = s.id
     JOIN internships i ON a.internship_id = i.id
     JOIN companies c ON i.company_id = c.id
     WHERE s.user_id = ?
     ORDER BY a.applied_at DESC"
);
$stmt->bind_param("i", $_SESSION["user_id"]);
$stmt->execute();
$applications = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Applications - Internship Portal</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "student_nav.php"; ?>
<main class="dashboard">
    <div class="page-heading"><div><p class="eyebrow">TRACKING</p><h1>My Applications</h1><p>Track the progress of every internship application.</p></div></div>
    <div class="table-card">
        <table>
            <thead><tr><th>Internship</th><th>Company</th><th>Applied On</th><th>Status</th></tr></thead>
            <tbody>
            <?php while ($row = $applications->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row["title"]); ?></td>
                    <td><?php echo htmlspecialchars($row["company_name"]); ?></td>
                    <td><?php echo date("d M Y", strtotime($row["applied_at"])); ?></td>
                    <td><span class="status"><?php echo htmlspecialchars($row["status"]); ?></span></td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>
