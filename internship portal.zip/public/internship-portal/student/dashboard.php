<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: ../login.php");
    exit;
}

$userId = $_SESSION["user_id"];

$stmt = $conn->prepare("SELECT COUNT(*) AS total FROM applications WHERE student_id = (SELECT id FROM students WHERE user_id = ?)");
$stmt->bind_param("i", $userId);
$stmt->execute();
$totalApplications = $stmt->get_result()->fetch_assoc()["total"];

$stmt = $conn->prepare("SELECT COUNT(*) AS total FROM applications WHERE student_id = (SELECT id FROM students WHERE user_id = ?) AND status = 'Shortlisted'");
$stmt->bind_param("i", $userId);
$stmt->execute();
$shortlisted = $stmt->get_result()->fetch_assoc()["total"];

$internshipCount = $conn->query("SELECT COUNT(*) AS total FROM internships WHERE status = 'Open'")->fetch_assoc()["total"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - Internship Portal</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "student_nav.php"; ?>

<main class="dashboard">
    <div class="page-heading">
        <div>
            <p class="eyebrow">STUDENT DASHBOARD</p>
            <h1>Welcome, <?php echo htmlspecialchars($_SESSION["name"]); ?>.</h1>
            <p>Manage your profile and internship applications.</p>
        </div>
        <a href="internships.php" class="btn primary">Find Internships</a>
    </div>

    <div class="stats-grid">
        <div class="stat-card"><span>Total Applications</span><strong><?php echo $totalApplications; ?></strong></div>
        <div class="stat-card"><span>Shortlisted</span><strong><?php echo $shortlisted; ?></strong></div>
        <div class="stat-card"><span>Open Internships</span><strong><?php echo $internshipCount; ?></strong></div>
    </div>

    <div class="quick-grid">
        <a class="quick-card" href="profile.php"><h3>My Profile</h3><p>Update your education, skills and resume.</p></a>
        <a class="quick-card" href="internships.php"><h3>Browse Internships</h3><p>Search current internship opportunities.</p></a>
        <a class="quick-card" href="applications.php"><h3>My Applications</h3><p>Track your application status.</p></a>
    </div>
</main>
</body>
</html>
