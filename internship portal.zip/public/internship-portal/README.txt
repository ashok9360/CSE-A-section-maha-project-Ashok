COLLEGE INTERNSHIP APPLICATION PORTAL
======================================

Technology:
PHP
MySQL
HTML
CSS
JavaScript
Sessions
Authentication
CRUD
Relationships
Joins
Forms
File Upload
Search / Filter

PROJECT STRUCTURE
-----------------
internship-portal/
    index.php
    login.php
    register.php
    logout.php

    student/
        dashboard.php
        profile.php
        internships.php
        apply.php
        applications.php
        student_nav.php

    company/
        dashboard.php
        add_internship.php
        internships.php
        applicants.php
        company_nav.php

    config/
        database.php

    css/
        style.css

    js/
        validation.js

    database.sql
    README.txt

SETUP
-----
1. Create a MySQL database named internship_portal.
2. Run all SQL from database.sql.
3. Open config/database.php.
4. Change host, username, password and database if your Nimbus/MySQL details are different.
5. Put the project inside the PHP server's web folder.
6. Start the PHP server.
7. Open index.php through the server URL.
8. Create a Student account.
9. Create a Company / Admin account.
10. Login as Company and post an internship.
11. Login as Student and search/apply.
12. Login as Company and update applicant status.

IMPORTANT
---------
The company account is called "Company / Admin" in the registration page.
Passwords are stored using PHP password_hash().
Login uses password_verify().
Student resumes are uploaded as PDF files to the uploads folder automatically.

If your MySQL database uses a different database name, change:
$database = "internship_portal";
inside config/database.php.
