<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Internship Portal - College Internship Portal</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<nav class="navbar">
    <div class="logo">Internship<span>Portal</span></div>
    <div class="nav-links">
        <a href="index.php">Home</a>
        <?php if (isset($_SESSION['user_id'])): ?>
            <a href="<?php echo $_SESSION['role'] === 'student' ? 'student/dashboard.php' : 'company/dashboard.php'; ?>">Dashboard</a>
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="login.php">Sign In</a>
            <a class="nav-button" href="register.php">Create Account</a>
        <?php endif; ?>
    </div>
</nav>

<section class="hero">
    <div class="hero-content">
        <p class="eyebrow">COLLEGE INTERNSHIP APPLICATION PORTAL</p>
        <h1>Find the right internship.<br><span>Build your future.</span></h1>
        <p class="hero-text">
            A simple platform for students to discover internships, apply online,
            and track their applications while companies manage opportunities and applicants.
        </p>
        <div class="hero-buttons">
            <a class="btn primary" href="register.php">Get Started</a>
            <a class="btn secondary" href="login.php">Sign In</a>
        </div>
    </div>
    <div class="hero-card">
        <div class="card-glow"></div>
        <h3>Application Journey</h3>
        <div class="journey">
            <div><b>01</b><span>Applied</span></div>
            <div><b>02</b><span>Under Review</span></div>
            <div><b>03</b><span>Shortlisted</span></div>
            <div><b>04</b><span>Interview</span></div>
            <div><b>05</b><span>Selected</span></div>
        </div>
    </div>
</section>

<section class="features section">
    <div class="section-title">
        <p class="eyebrow">PLATFORM FEATURES</p>
        <h2>Everything in one place</h2>
    </div>
    <div class="feature-grid">
        <div class="feature-card"><div class="feature-icon">01</div><h3>Student Profile</h3><p>Create your profile, add skills and upload your resume.</p></div>
        <div class="feature-card"><div class="feature-icon">02</div><h3>Find Internships</h3><p>Search and filter internship opportunities by role and location.</p></div>
        <div class="feature-card"><div class="feature-icon">03</div><h3>Track Applications</h3><p>Follow every application from Applied to Selected or Rejected.</p></div>
        <div class="feature-card"><div class="feature-icon">04</div><h3>Company Management</h3><p>Companies can post internships and manage student applications.</p></div>
    </div>
</section>

<footer>
    <p>© <?php echo date("Y"); ?> InternHub College Internship Portal</p>
</footer>
<script src="js/validation.js"></script>
</body>
</html>
