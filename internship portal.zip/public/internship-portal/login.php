<?php
session_start();
require_once "config/database.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"]);
    $password = $_POST["password"];

    if ($email === "" || $password === "") {
        $error = "Please enter email and password.";
    } else {
        $stmt = $conn->prepare("SELECT id, name, email, password, role FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            if (password_verify($password, $user["password"])) {
                $_SESSION["user_id"] = $user["id"];
                $_SESSION["name"] = $user["name"];
                $_SESSION["role"] = $user["role"];

                if ($user["role"] === "student") {
                    header("Location: student/dashboard.php");
                } else {
                    header("Location: company/dashboard.php");
                }
                exit;
            }
        }

        $error = "Invalid email or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In - Internship Portal</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="auth-page">
<div class="auth-container">
    <div class="auth-brand">
        <a href="index.php" class="logo">Internship<span>Portal</span></a>
        <h1>Welcome back.</h1>
        <p>Sign in to continue to your internship dashboard.</p>
    </div>

    <div class="auth-card">
        <h2>Sign In</h2>
        <p class="muted">Enter your account details below.</p>

        <?php if ($error): ?>
            <div class="alert error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="POST" onsubmit="return validateLogin()">
            <label>Email Address</label>
            <input type="email" name="email" id="email" placeholder="you@example.com">

            <label>Password</label>
            <input type="password" name="password" id="password" placeholder="Enter your password">

            <button type="submit" class="btn primary full">Sign In</button>
        </form>

        <p class="auth-bottom">Don't have an account? <a href="register.php">Create one</a></p>
    </div>
</div>
<script src="js/validation.js"></script>
</body>
</html>
