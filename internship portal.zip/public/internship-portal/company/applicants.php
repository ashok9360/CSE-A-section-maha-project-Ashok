<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "company") {
    header("Location: ../login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $applicationId = intval($_POST["application_id"]);
    $status = $_POST["status"];
    $allowed = ["Under Review", "Shortlisted", "Interview", "Selected", "Rejected"];

    if (in_array($status, $allowed)) {
        $update = $conn->prepare(
            "UPDATE applications a
             JOIN internships i ON a.internship_id = i.id
             JOIN companies c ON i.company_id = c.id
             SET a.status = ?
             WHERE a.id = ? AND c.user_id = ?"
        );
        $update->bind_param("sii", $status, $applicationId, $_SESSION["user_id"]);
        $update->execute();
    }
}

$stmt = $conn->prepare(
    "SELECT a.id, a.status, a.applied_at, u.name, u.email,
            i.title, s.skills, s.college
     FROM applications a
     JOIN students s ON a.student_id = s.id
     JOIN users u ON s.user_id = u.id
     JOIN internships i ON a.internship_id = i.id
     JOIN companies c ON i.company_id = c.id
     WHERE c.user_id = ?
     ORDER BY a.applied_at DESC"
);
$stmt->bind_param("i", $_SESSION["user_id"]);
$stmt->execute();
$applicants = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Applicants - Internship Portal</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "company_nav.php"; ?>
<main class="dashboard">
    <div class="page-heading"><div><p class="eyebrow">APPLICATIONS</p><h1>Applicants</h1><p>Review applicants and update their application status.</p></div></div>

    <div class="table-card">
        <table>
            <thead><tr><th>Student</th><th>Internship</th><th>Skills</th><th>Applied</th><th>Status</th><th>Update</th></tr></thead>
            <tbody>
            <?php while ($row = $applicants->fetch_assoc()): ?>
                <tr>
                    <td><strong><?php echo htmlspecialchars($row["name"]); ?></strong><br><small><?php echo htmlspecialchars($row["email"]); ?></small></td>
                    <td><?php echo htmlspecialchars($row["title"]); ?></td>
                    <td><?php echo htmlspecialchars($row["skills"] ?? "Not added"); ?></td>
                    <td><?php echo date("d M Y", strtotime($row["applied_at"])); ?></td>
                    <td><span class="status"><?php echo htmlspecialchars($row["status"]); ?></span></td>
                    <td>
                        <form method="POST" class="inline-form">
                            <input type="hidden" name="application_id" value="<?php echo $row["id"]; ?>">
                            <select name="status">
                                <option>Under Review</option>
                                <option>Shortlisted</option>
                                <option>Interview</option>
                                <option>Selected</option>
                                <option>Rejected</option>
                            </select>
                            <button class="btn small" type="submit">Update</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>
