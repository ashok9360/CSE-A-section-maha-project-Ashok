<nav class="navbar dashboard-nav">
    <div class="logo">Internship<span>Portal</span></div>
    <div class="nav-links">
        <a href="dashboard.php">Dashboard</a>
        <a href="add_internship.php">Add Internship</a>
        <a href="internships.php">My Internships</a>
        <a href="applicants.php">Applicants</a>
        <a href="../logout.php">Logout</a>
    </div>
</nav>