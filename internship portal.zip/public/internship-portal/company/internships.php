<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "company") {
    header("Location: ../login.php");
    exit;
}

$stmt = $conn->prepare(
    "SELECT i.*, COUNT(a.id) AS applicant_count
     FROM internships i
     LEFT JOIN applications a ON i.id = a.internship_id
     JOIN companies c ON i.company_id = c.id
     WHERE c.user_id = ?
     GROUP BY i.id
     ORDER BY i.created_at DESC"
);
$stmt->bind_param("i", $_SESSION["user_id"]);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Internships - Internship Portal</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "company_nav.php"; ?>
<main class="dashboard">
    <div class="page-heading"><div><p class="eyebrow">MANAGEMENT</p><h1>My Internships</h1><p>View the internships you have posted.</p></div><a class="btn primary" href="add_internship.php">Add New</a></div>

    <div class="table-card">
        <table>
            <thead><tr><th>Title</th><th>Location</th><th>Status</th><th>Applicants</th></tr></thead>
            <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row["title"]); ?></td>
                    <td><?php echo htmlspecialchars($row["location"]); ?></td>
                    <td><span class="status open"><?php echo htmlspecialchars($row["status"]); ?></span></td>
                    <td><?php echo $row["applicant_count"]; ?></td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>
