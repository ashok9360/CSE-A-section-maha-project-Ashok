<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "company") {
    header("Location: ../login.php");
    exit;
}

$userId = $_SESSION["user_id"];

$stmt = $conn->prepare("SELECT id, company_name FROM companies WHERE user_id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$company = $stmt->get_result()->fetch_assoc();
$companyId = $company["id"];

$stmt = $conn->prepare("SELECT COUNT(*) AS total FROM internships WHERE company_id = ?");
$stmt->bind_param("i", $companyId);
$stmt->execute();
$totalInternships = $stmt->get_result()->fetch_assoc()["total"];

$stmt = $conn->prepare(
    "SELECT COUNT(*) AS total FROM applications a
     JOIN internships i ON a.internship_id = i.id
     WHERE i.company_id = ?"
);
$stmt->bind_param("i", $companyId);
$stmt->execute();
$totalApplicants = $stmt->get_result()->fetch_assoc()["total"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Dashboard - Internship Portal</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "company_nav.php"; ?>
<main class="dashboard">
    <div class="page-heading">
        <div><p class="eyebrow">COMPANY DASHBOARD</p><h1>Welcome, <?php echo htmlspecialchars($company["company_name"] ?? $_SESSION["name"]); ?>.</h1><p>Manage your internship opportunities and applicants.</p></div>
        <a href="add_internship.php" class="btn primary">Post Internship</a>
    </div>

    <div class="stats-grid">
        <div class="stat-card"><span>Internships Posted</span><strong><?php echo $totalInternships; ?></strong></div>
        <div class="stat-card"><span>Total Applicants</span><strong><?php echo $totalApplicants; ?></strong></div>
    </div>

    <div class="quick-grid">
        <a class="quick-card" href="add_internship.php"><h3>Add Internship</h3><p>Create a new internship opportunity.</p></a>
        <a class="quick-card" href="internships.php"><h3>My Internships</h3><p>View and manage your posted opportunities.</p></a>
        <a class="quick-card" href="applicants.php"><h3>Applicants</h3><p>Review students and update application status.</p></a>
    </div>
</main>
</body>
</html>
