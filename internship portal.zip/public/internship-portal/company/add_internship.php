<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "company") {
    header("Location: ../login.php");
    exit;
}

$message = "";

$stmt = $conn->prepare("SELECT id FROM companies WHERE user_id = ?");
$stmt->bind_param("i", $_SESSION["user_id"]);
$stmt->execute();
$companyId = $stmt->get_result()->fetch_assoc()["id"];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $title = trim($_POST["title"]);
    $description = trim($_POST["description"]);
    $location = trim($_POST["location"]);
    $skills = trim($_POST["skills"]);
    $duration = trim($_POST["duration"]);
    $stipend = trim($_POST["stipend"]);

    if ($title === "" || $description === "" || $location === "") {
        $message = "Please fill in the required fields.";
    } else {
        $insert = $conn->prepare(
            "INSERT INTO internships (company_id, title, description, location, skills, duration, stipend, status)
             VALUES (?, ?, ?, ?, ?, ?, ?, 'Open')"
        );
        $insert->bind_param("issssss", $companyId, $title, $description, $location, $skills, $duration, $stipend);

        if ($insert->execute()) {
            $message = "Internship posted successfully.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Internship - Internship Portal</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "company_nav.php"; ?>
<main class="dashboard narrow">
    <div class="page-heading"><div><p class="eyebrow">OPPORTUNITY MANAGEMENT</p><h1>Post an Internship</h1><p>Create a clear and useful internship listing.</p></div></div>
    <?php if ($message): ?><div class="alert success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>

    <div class="form-card">
        <form method="POST">
            <label>Internship Title *</label>
            <input type="text" name="title" placeholder="e.g. Full Stack Developer Intern">

            <label>Description *</label>
            <textarea name="description" rows="6" placeholder="Describe responsibilities and requirements..."></textarea>

            <div class="form-grid">
                <div><label>Location *</label><input type="text" name="location" placeholder="Chennai / Remote"></div>
                <div><label>Skills</label><input type="text" name="skills" placeholder="PHP, MySQL, JavaScript"></div>
                <div><label>Duration</label><input type="text" name="duration" placeholder="3 Months"></div>
                <div><label>Stipend</label><input type="text" name="stipend" placeholder="₹10,000 / month"></div>
            </div>

            <button type="submit" class="btn primary">Publish Internship</button>
        </form>
    </div>
</main>
</body>
</html>
