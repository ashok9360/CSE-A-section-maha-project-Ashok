<?php
$host = "db01.dbhost.dev";
$username = "user_455982p5s";
$password = "p455982p5s";
$database = "db_455982p5s";

$conn = new mysqli($host, $username, $password, $database, 5051);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
?>